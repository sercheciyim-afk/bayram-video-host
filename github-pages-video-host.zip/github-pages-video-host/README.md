# GitHub Pages Video Host

Эта папка нужна, чтобы хранить два MP4-файла на GitHub Pages и брать стабильные прямые ссылки для Tilda.

## 1. Что положить в `videos/`

Переименуй видео именно так:

- `videos/bayram-desktop-hq.mp4`
- `videos/bayram-mobile-hq.mp4`

Важно: каждый файл должен быть меньше 100 MB, если загружать в GitHub обычным способом.

## 2. Как загрузить через GitHub

1. Создай новый public repository на GitHub, например `bayram-video-host`.
2. Нажми `Add file` -> `Upload files`.
3. Загрузи содержимое этой папки целиком:
   - `index.html`
   - папку `videos`
   - папку `tilda`
   - `README.md`
4. Открой `Settings` -> `Pages`.
5. В `Build and deployment` выбери:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
6. Нажми `Save`.

Через пару минут сайт будет доступен по адресу:

```txt
https://USERNAME.github.io/bayram-video-host/
```

А видео будут доступны здесь:

```txt
https://USERNAME.github.io/bayram-video-host/videos/bayram-desktop-hq.mp4
https://USERNAME.github.io/bayram-video-host/videos/bayram-mobile-hq.mp4
```

## 3. Что вставлять в Tilda

Открой:

```txt
tilda/scroll-video-tilda.txt
```

Замени вверху:

```js
var baseUrl = "https://USERNAME.github.io/bayram-video-host";
```

на свой реальный GitHub Pages URL.

Потом вставь весь код в блок `T123 HTML-код`.

